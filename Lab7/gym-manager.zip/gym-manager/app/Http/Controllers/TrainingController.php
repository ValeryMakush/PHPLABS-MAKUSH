<?php
// app/Http/Controllers/TrainingController.php

namespace App\Http\Controllers;

use App\Models\Training;
use App\Models\Client;
use App\Models\Trainer;
use App\Models\TrainingType;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class TrainingController extends Controller
{
    public function index()
    {
        $trainings = Training::with(['trainer', 'trainingType', 'clients'])
            ->paginate(10);
            
        return view('trainings.index', compact('trainings'));
    }

    public function create(): View
    {
        $trainers = Trainer::all();
        $clients = Client::all();
        $trainingTypes = TrainingType::all();
        
        return view('trainings.create', compact('trainers', 'clients', 'trainingTypes'));
    }

    public function store(Request $request)
{
    try {
        DB::beginTransaction();
        
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'training_type_id' => 'required|exists:training_types,id',
            'trainer_id' => 'required|exists:trainers,id',
            'training_date' => 'required|date_format:Y-m-d\TH:i',
            'sessions_count' => 'required|integer|min:1',
            'clients' => 'required|array',
            'clients.*' => 'exists:clients,id',
        ]);

        $training = Training::create([
            'name' => $validated['name'],
            'training_type_id' => $validated['training_type_id'],
            'trainer_id' => $validated['trainer_id'],
            'training_date' => $validated['training_date'],
            'sessions_count' => $validated['sessions_count'],
            'status' => 'scheduled'
        ]);

        $training->clients()->attach($validated['clients'], [
            'trainer_id' => $validated['trainer_id']
        ]);

        DB::commit();

        return redirect()
            ->route('trainings.index')
            ->with('success', 'Тренування успішно призначено');

    } catch (\Exception $e) {
        DB::rollBack();
        Log::error('Training creation failed: ' . $e->getMessage());
        
        return redirect()
            ->back()
            ->withInput()
            ->with('error', 'Помилка при створенні тренування: ' . $e->getMessage());
    }
}
}
