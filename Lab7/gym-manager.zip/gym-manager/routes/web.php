<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    ClientController,
    TrainerController, 
    TrainingController,
    DashboardController,
    AssignmentController,
    TrainingTypeController,
    ProfileController
};

require __DIR__.'/auth.php';

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Гостьові маршрути
Route::get('/', function () {
    return view('welcome');
})->name('welcome');

// Аутентифіковані маршрути
Route::middleware(['auth'])->group(function () {
    // Панель керування
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    Route::resources([
        'clients' => ClientController::class,
        'trainers' => TrainerController::class,
    ]);

    Route::resource('training-types', TrainingTypeController::class);
    Route::resource('trainings', TrainingController::class);

    Route::get('assignments/create', [AssignmentController::class, 'create'])->name('assignments.create');
    Route::post('assignments', [AssignmentController::class, 'store'])->name('assignments.store');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});
