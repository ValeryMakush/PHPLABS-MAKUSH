<?php

namespace App\Http\Controllers;

use App\Models\Trainer;
use Illuminate\Http\Request;
use Illuminate\View\View;

class TrainerController extends Controller
{
    // Список тренерів
    public function index()
    {
        $trainers = Trainer::all();
        return view('trainers.index', compact('trainers'));
    }

    // Форма створення тренера
    public function create()
    {
        return view('trainers.create');
    }


    // Збереження нового тренера
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:trainers',
            'phone' => 'nullable|string|max:20',
            'specialization' => 'nullable|string|max:255',
        ]);

        $trainer = Trainer::create($validated);

        return redirect()
            ->route('trainers.index')
            ->with('success', 'Тренера успішно додано');
    }

    // Форма редагування тренера
    public function edit(Trainer $trainer)
    {
        return view('trainers.edit', compact('trainer'));
    }

    // Оновлення тренера
    public function update(Request $request, Trainer $trainer)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $trainer->update($validated);

        return redirect()->route('trainers.index')->with('success', 'Тренер оновлений');
    }

    // Видалення тренера
    public function destroy(Trainer $trainer)
    {
        $trainer->delete();
        return redirect()->route('trainers.index')->with('success', 'Тренер видалений');
    }
    public function report(): View
    {
        $trainers = Trainer::with(['trainings.clients', 'clients'])
            ->get();

        return view('trainers.report', compact('trainers'));
    }
}