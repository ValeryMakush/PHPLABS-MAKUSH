<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Client extends Model
{
    protected $fillable = [
        'name',
        'email',
        'phone'
    ];

    public function trainings(): BelongsToMany
    {
        return $this->belongsToMany(Training::class, 'training_client_trainer')
                    ->withPivot('trainer_id')
                    ->withTimestamps();
    }
}
