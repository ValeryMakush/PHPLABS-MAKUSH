
@extends('adminlte::page')

@section('title', 'Редагування типу тренування')

@section('content_header')
    <h1>Редагування типу тренування</h1>
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <form action="{{ route('training-types.update', $training_type->id) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="name">Назва</label>
                <input type="text" 
                       class="form-control @error('name') is-invalid @enderror" 
                       id="name" 
                       name="name" 
                       value="{{ old('name', $training_type->name) }}" 
                       required>
                @error('name')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <div class="form-group">
                <label for="description">Опис</label>
                <textarea class="form-control @error('description') is-invalid @enderror" 
                          id="description" 
                          name="description" 
                          rows="3">{{ old('description', $training_type->description) }}</textarea>
                @error('description')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <div class="d-flex justify-content-between">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save mr-1"></i> Зберегти
                </button>
                <a href="{{ route('training-types.index') }}" class="btn btn-default">
                    <i class="fas fa-times mr-1"></i> Скасувати
                </a>
            </div>
        </form>
    </div>
</div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script></script>
@stop
