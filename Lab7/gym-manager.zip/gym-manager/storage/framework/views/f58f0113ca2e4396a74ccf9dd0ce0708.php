

<?php $__env->startSection('title', 'Редагування клієнта'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Редагувати клієнта</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('clients.update', $client)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label>Ім’я</label>
            <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $client->name)); ?>" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $client->email)); ?>" required>
        </div>

        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $client->phone)); ?>">
        </div>

        <button type="submit" class="btn btn-success">Зберегти</button>
        <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-secondary">Назад</a>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/clients/edit.blade.php ENDPATH**/ ?>