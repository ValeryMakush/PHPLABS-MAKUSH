@extends('adminlte::page')

@section('title', 'Адмін-панель')

@section('content_header')
    <h1>Головна сторінка</h1>
@stop

@section('content')
    <p>Ласкаво просимо до системи управління тренажерним залом.</p>
@stop

@section('right-sidebar')
    {{-- Не обов’язково --}}
@stop

@section('sidebar')
    @include('layouts.sidebar') {{-- ось тут ми додаємо кастомне меню --}}
@stop
