@extends('adminlte::page')

@section('title', 'Dashboard')

@section('content_header')
    <h1>Dashboard</h1>
@stop

@section('content')
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="small-box bg-info">
            <div class="inner">
                <h3>{{ $stats['trainings_count'] }}</h3>
                <p>Тренування</p>
            </div>
            <div class="icon">
                <i class="fas fa-dumbbell"></i>
            </div>
            <a href="{{ route('trainings.index') }}" class="small-box-footer">
                Детальніше <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <div class="small-box bg-success">
            <div class="inner">
                <h3>{{ $stats['clients_count'] }}</h3>
                <p>Клієнти</p>
            </div>
            <div class="icon">
                <i class="fas fa-users"></i>
            </div>
            <a href="{{ route('clients.index') }}" class="small-box-footer">
                Детальніше <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <div class="small-box bg-warning">
            <div class="inner">
                <h3>{{ $stats['trainers_count'] ?? 0 }}</h3>
                <p>Тренери</p>
            </div>
            <div class="icon">
                <i class="fas fa-user-tie"></i>
            </div>
            <a href="{{ route('trainers.index') }}" class="small-box-footer">
                Детальніше <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <div class="small-box bg-danger">
            <div class="inner">
                <h3>{{ $stats['today_trainings'] ?? 0 }}</h3>
                <p>Тренування сьогодні</p>
            </div>
            <div class="icon">
                <i class="fas fa-calendar-day"></i>
            </div>
            <a href="{{ route('trainings.index') }}" class="small-box-footer">
                Детальніше <i class="fas fa-arrow-circle-right"></i>
            </a>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Останні тренування</h3>
            </div>
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Назва</th>
                            <th>Дата</th>
                            <th>Тренер</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($latest_trainings ?? [] as $training)
                            <tr>
                                <td>{{ $training->name }}</td>
                                <td>{{ $training->training_date?->format('d.m.Y') }}</td>
                                <td>{{ $training->trainer?->name ?? 'Не призначено' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="text-center">Немає тренувань</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Активні клієнти</h3>
            </div>
            <div class="card-body p-0">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Ім'я</th>
                            <th>Email</th>
                            <th>К-сть тренувань</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($active_clients ?? [] as $client)
                            <tr>
                                <td>{{ $client->name }}</td>
                                <td>{{ $client->email }}</td>
                                <td>{{ $client->trainings_count }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="3" class="text-center">Немає активних клієнтів</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@stop

@push('scripts')
<script>
    console.log('Dashboard loaded!');
</script>
@endpush
