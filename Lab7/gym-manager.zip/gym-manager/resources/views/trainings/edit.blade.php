@extends('adminlte::page')

@section('title', 'Редагувати вид тренування')

@section('content_header')
    <h1>Редагувати вид тренування</h1>
@stop

@section('content')
    <form action="{{ route('trainings.update', $training->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="form-group">
            <label>Назва</label>
            <input type="text" name="name" value="{{ $training->name }}" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Опис</label>
            <textarea name="description" class="form-control">{{ $training->description }}</textarea>
        </div>
        <button type="submit" class="btn btn-primary">Оновити</button>
    </form>
@stop
