<?php

namespace App\Http\Controllers;

use App\Models\TrainingType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class TrainingTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): View
    {
        $types = TrainingType::all();
        return view('training_types.index', compact('types'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('training_types.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255|unique:training_types',
            'description' => 'nullable|string'
        ]);

        TrainingType::create($validated);

        return redirect()->route('training-types.index')
            ->with('success', 'Тип тренування додано');
    }

    /**
     * Display the specified resource.
     */
    public function show(TrainingType $trainingType) // Використовуйте Model Binding
    {
        // Цей метод може бути використаний для перегляду одного типу тренування
        return view('training_types.show', compact('trainingType'));
    }

    /**
     * Show the form for editing the specified resource.
     */
   public function edit(TrainingType $training_type)
{
    return view('training_types.edit', compact('training_type'));
}
    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, TrainingType $trainingType) // Використовуйте Model Binding
    {
        $validated = $request->validate([
            'name' => 'required|string|unique:training_types,name,' . $trainingType->id, // Додано unique, ігноруючи поточний ID
            'description' => 'string|nullable',
        ]);

        $trainingType->update($validated);

        return redirect()->route('training-types.index')->with('success', 'Тип тренування оновлено успішно!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TrainingType $training_type)
    {
        try {
            DB::beginTransaction();

            // First check if there are any associated trainings
            if ($training_type->trainings()->exists()) {
                // Delete the related records from training_client_trainer
                foreach ($training_type->trainings as $training) {
                    $training->clients()->detach();
                }
                
                // Delete the associated trainings
                $training_type->trainings()->delete();
            }
            
            // Finally delete the training type
            $training_type->delete();
            
            DB::commit();

            return redirect()
                ->route('training-types.index')
                ->with('success', 'Тип тренування успішно видалено');

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()
                ->route('training-types.index')
                ->with('error', 'Помилка при видаленні типу тренування');
        }
    }
}