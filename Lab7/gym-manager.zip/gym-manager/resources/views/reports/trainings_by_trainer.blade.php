@extends('adminlte::page')

@section('title', 'Звіт по тренерам')

@section('content_header')
    <h1>Звіт по тренерам</h1>
@stop

@section('content')
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ім’я тренера</th>
                <th>Кількість тренувань</th>
                <th>Клієнти</th>
            </tr>
        </thead>
        <tbody>
            @foreach($trainers as $trainer)
<tr>
    <td>{{ $trainer->name }}</td>
    <td>{{ $trainer->trainings_count }}</td>
    <td>
        @php
            $clients = $trainer->trainings->pluck('client')->filter()->unique('id');
        @endphp

        @if($clients->isEmpty())
            <em>Клієнти відсутні</em>
        @else
            <ul>
                @foreach($clients as $client)
                    <li>{{ $client->name }}</li>
                @endforeach
            </ul>
        @endif
    </td>
</tr>
@endforeach

        </tbody>
    </table>
@stop
