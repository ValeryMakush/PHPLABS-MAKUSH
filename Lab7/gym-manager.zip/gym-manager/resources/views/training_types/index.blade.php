@extends('adminlte::page')

@section('title', 'Види тренувань')

@section('content_header')
    <div class="d-flex justify-content-between">
        <h1>Види тренувань</h1>
        <a href="{{ route('training-types.create') }}" class="btn btn-primary">
            <i class="fas fa-plus"></i> Додати вид тренування
        </a>
    </div>
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 50px">#</th>
                    <th>Назва</th>
                    <th>Опис</th>
                    <th style="width: 150px">Дії</th>
                </tr>
            </thead>
            <tbody>
                @forelse($types as $type)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ $type->name }}</td>
                        <td>{{ $type->description ?? 'Немає опису' }}</td>
                        <td>
                            <a href="{{ route('training-types.edit', $type->id) }}" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i> Редагувати
                            </a>
                            <form action="{{ route('training-types.destroy', $type->id) }}" method="POST" style="display:inline-block;">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" class="text-center">Немає видів тренувань</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@stop

@section('css')
    {{-- Додаткові CSS, якщо потрібно --}}
@stop

@section('js')
    {{-- Додаткові JS, якщо потрібно --}}
@stop