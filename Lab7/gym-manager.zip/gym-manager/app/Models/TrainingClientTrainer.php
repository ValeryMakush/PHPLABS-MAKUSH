<?php

namespace App\Http\Controllers;

use App\Models\Training;
use App\Models\Trainer;
use App\Models\TrainingType;
use Illuminate\Http\Request;

class TrainingController extends Controller
{
    // Список тренувань
    public function index()
    {
        $trainings = Training::with(['trainer', 'trainingType'])->get();
        return view('trainings.index', compact('trainings'));
    }

    // Форма створення тренування
    public function create()
    {
        $trainers = Trainer::all();
        $trainingTypes = TrainingType::all();

        return view('trainings.create', compact('trainers', 'trainingTypes'));
    }

    // Збереження нового тренування
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'training_type_id' => 'required|exists:training_types,id',
            'trainer_id' => 'required|exists:trainers,id',
            'training_date' => 'required|date',
        ]);

        Training::create($validated);

        return redirect()->route('trainings.index')->with('success', 'Тренування додано');
    }

    // Форма редагування тренування
    public function edit(Training $training)
    {
        $trainers = Trainer::all();
        $trainingTypes = TrainingType::all();

        return view('trainings.edit', compact('training', 'trainers', 'trainingTypes'));
    }

    // Оновлення тренування
    public function update(Request $request, Training $training)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'training_type_id' => 'required|exists:training_types,id',
            'trainer_id' => 'required|exists:trainers,id',
            'training_date' => 'required|date',
        ]);

        $training->update($validated);

        return redirect()->route('trainings.index')->with('success', 'Тренування оновлено');
    }

    // Видалення тренування
    public function destroy(Training $training)
    {
        $training->delete();
        return redirect()->route('trainings.index')->with('success', 'Тренування видалено');
    }
}
