

<?php $__env->startSection('title', 'Клієнти'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Список клієнтів</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary mb-3">+ Додати клієнта</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ім’я</th>
                <th>Email</th>
                <th>Телефон</th>
                <th>Дії</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($client->name); ?></td>
                    <td><?php echo e($client->email); ?></td>
                    <td><?php echo e($client->phone); ?></td>
                    <td>
                        <a href="<?php echo e(route('clients.edit', $client)); ?>" class="btn btn-sm btn-warning">Редагувати</a>
                        <form action="<?php echo e(route('clients.destroy', $client)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені?')">Видалити</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/clients/index.blade.php ENDPATH**/ ?>