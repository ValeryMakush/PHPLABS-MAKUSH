<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Trainer;
use App\Models\Training;
use Illuminate\Http\Request;
use App\Models\TrainingType;
use Illuminate\Support\Facades\DB;

class AssignmentController extends Controller
{
    

public function create()
{
    $clients = Client::all();
    $trainers = Trainer::all();
    $trainings = TrainingType::all();  // Ось сюди додай цю змінну

    return view('assignments.create', compact('clients', 'trainers', 'trainings'));
}
public function store(Request $request)
{
    $request->validate([
        'client_id' => 'required|exists:clients,id',
        'trainer_id' => 'required|exists:trainers,id',
        'training_id' => 'required|exists:trainings,id',
        'quantity' => 'required|integer|min:1',
    ]);

    DB::table('training_client_trainer')->insert([
        'client_id' => $request->client_id,
        'trainer_id' => $request->trainer_id,
        'training_id' => $request->training_id,
        'quantity' => $request->quantity,
        'created_at' => now(),
        'updated_at' => now(),
    ]);

    return redirect()->back()->with('success', 'Тренування призначено успішно!');
}
}
