

<?php $__env->startSection('title', 'Редагування тренера'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Редагувати тренера</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('trainers.update', $trainer)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label>Ім’я</label>
            <input type="text" name="name" value="<?php echo e($trainer->name); ?>" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e($trainer->email); ?>" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" value="<?php echo e($trainer->phone); ?>" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Зберегти</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/trainers/edit.blade.php ENDPATH**/ ?>