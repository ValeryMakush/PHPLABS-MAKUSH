<?php

namespace App\Http\Controllers;

use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ClientController extends Controller
{
    public function index()
    {
        $clients = Client::withCount('trainings')->paginate(10);
        return view('clients.index', compact('clients'));
    }

    public function create()
    {
        return view('clients.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:clients',
            'phone' => 'nullable|string|max:20'
        ]);

        Client::create($validated);
        return redirect()->route('clients.index')->with('success', 'Клієнта додано');
    }

    public function edit(Client $client)
    {
        return view('clients.edit', compact('client'));
    }

    public function update(Request $request, Client $client)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:clients,email,' . $client->id,
            'phone' => 'nullable',
        ]);

        $client->update($request->all());

        return redirect()->route('clients.index')->with('success', 'Клієнта оновлено');
    }

    public function destroy(Client $client)
    {
        try {
            DB::beginTransaction();
            
            // First delete related records from pivot table
            $client->trainings()->detach();
            
            // Then delete the client
            $client->delete();
            
            DB::commit();
            return redirect()->route('clients.index')->with('success', 'Клієнта успішно видалено');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('clients.index')->with('error', 'Помилка при видаленні клієнта');
        }
    }
}
