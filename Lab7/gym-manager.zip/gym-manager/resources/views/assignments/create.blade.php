@extends('adminlte::page')

@section('title', 'Призначити тренування')

@section('content_header')
    <h1>Призначити тренування</h1>
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <form action="{{ route('trainings.store') }}" method="POST">
            @csrf
            
            <div class="form-group">
                <label for="training_type_id">Вид тренування</label>
                <select class="form-control @error('training_type_id') is-invalid @enderror" 
                        id="training_type_id" name="training_type_id" required>
                    <option value="">Виберіть вид тренування</option>
                    @foreach($trainingTypes as $type)
                        <option value="{{ $type->id }}" {{ old('training_type_id') == $type->id ? 'selected' : '' }}>
                            {{ $type->name }}
                        </option>
                    @endforeach
                </select>
                @error('training_type_id')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <div class="form-group">
                <label for="name">Назва тренування</label>
                <input type="text" class="form-control @error('name') is-invalid @enderror" 
                       id="name" name="name" value="{{ old('name') }}" required>
                @error('name')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <!-- ...existing form fields for date, time, trainer, clients... -->

            <button type="submit" class="btn btn-primary">Призначити тренування</button>
            <a href="{{ route('trainings.index') }}" class="btn btn-default">Скасувати</a>
        </form>
    </div>
</div>
@stop

@section('css')
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
@stop

@section('js')
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
    $(document).ready(function() {
        $('.select2').select2({
            placeholder: "Виберіть клієнтів",
            allowClear: true
        });
    });
</script>
@stop