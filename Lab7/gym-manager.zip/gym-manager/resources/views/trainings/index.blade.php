
@extends('adminlte::page')

@section('title', 'Тренування')

@section('content_header')
    <h1>Тренування</h1>
@stop

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Список тренувань</h3>
        <div class="card-tools">
            <a href="{{ route('trainings.create') }}" class="btn btn-primary">
                <i class="fas fa-plus"></i> Додати тренування
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Назва</th>
                    <th>Тренер</th>
                    <th>Тип</th>
                    <th>Дата</th>
                    <th>Дії</th>
                </tr>
            </thead>
            <tbody>
                @forelse($trainings as $training)
                    <tr>
                        <td>{{ $training->id }}</td>
                        <td>{{ $training->name }}</td>
                        <td>{{ $training->trainer->name ?? 'Не призначено' }}</td>
                        <td>{{ $training->trainingType->name ?? 'Не визначено' }}</td>
                        <td>{{ $training->training_date?->format('d.m.Y H:i') }}</td>
                        <td>
                            <a href="{{ route('trainings.edit', $training) }}" class="btn btn-sm btn-info">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="{{ route('trainings.destroy', $training) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center">Тренувань не знайдено</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($trainings->hasPages())
        <div class="card-footer">
            {{ $trainings->links() }}
        </div>
    @endif
</div>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script>console.log('Trainings page loaded');</script>
@stop