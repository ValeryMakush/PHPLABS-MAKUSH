@extends('adminlte::page')

@section('title', 'Створити тип тренування')

@section('content_header')
    <h1>Створити новий тип тренування</h1>
@stop

@section('content')
<div class="card">
    <div class="card-body">
        <form action="{{ route('training-types.store') }}" method="POST">
            @csrf
            
            <div class="form-group">
                <label for="name">Назва тренування</label>
                <input type="text" 
                       class="form-control @error('name') is-invalid @enderror" 
                       id="name" 
                       name="name" 
                       value="{{ old('name') }}" 
                       placeholder="Наприклад: Йога, Біг, Силове тренування"
                       required>
                @error('name')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <div class="form-group">
                <label for="description">Опис</label>
                <textarea class="form-control @error('description') is-invalid @enderror" 
                          id="description" 
                          name="description" 
                          rows="3"
                          placeholder="Опис тренування">{{ old('description') }}</textarea>
                @error('description')
                    <span class="invalid-feedback">{{ $message }}</span>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary">Зберегти</button>
            <a href="{{ route('training-types.index') }}" class="btn btn-default">Скасувати</a>
        </form>
    </div>
</div>
@stop

@section('css')
    {{-- Додаткові CSS, якщо потрібно --}}
@stop

@section('js')
    {{-- Додаткові JS, якщо потрібно --}}
@stop