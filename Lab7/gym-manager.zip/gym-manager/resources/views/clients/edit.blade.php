@extends('adminlte::page')

@section('title', 'Редагування клієнта')

@section('content_header')
    <h1>Редагувати клієнта</h1>
@stop

@section('content')
    <form action="{{ route('clients.update', $client) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label>Ім’я</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $client->name) }}" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" value="{{ old('email', $client->email) }}" required>
        </div>

        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" class="form-control" value="{{ old('phone', $client->phone) }}">
        </div>

        <button type="submit" class="btn btn-success">Зберегти</button>
        <a href="{{ route('clients.index') }}" class="btn btn-secondary">Назад</a>
    </form>
@stop
