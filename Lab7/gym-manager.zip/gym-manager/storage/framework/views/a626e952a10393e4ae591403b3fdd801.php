


<?php $__env->startSection('title', 'Тренування'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Тренування</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Список тренувань</h3>
        <div class="card-tools">
            <a href="<?php echo e(route('trainings.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Додати тренування
            </a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Назва</th>
                    <th>Тренер</th>
                    <th>Тип</th>
                    <th>Дата</th>
                    <th>Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $training): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($training->id); ?></td>
                        <td><?php echo e($training->name); ?></td>
                        <td><?php echo e($training->trainer->name ?? 'Не призначено'); ?></td>
                        <td><?php echo e($training->trainingType->name ?? 'Не визначено'); ?></td>
                        <td><?php echo e($training->training_date?->format('d.m.Y H:i')); ?></td>
                        <td>
                            <a href="<?php echo e(route('trainings.edit', $training)); ?>" class="btn btn-sm btn-info">
                                <i class="fas fa-edit"></i>
                            </a>
                            <form action="<?php echo e(route('trainings.destroy', $training)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center">Тренувань не знайдено</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($trainings->hasPages()): ?>
        <div class="card-footer">
            <?php echo e($trainings->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>console.log('Trainings page loaded');</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/trainings/index.blade.php ENDPATH**/ ?>