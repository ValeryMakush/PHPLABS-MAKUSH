<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TrainingClientTrainerSeeder extends Seeder
{
    public function run(): void
    {
        DB::table('training_client_trainer')->insert([
            [
                'training_id' => 1,
                'client_id' => 1,
                'trainer_id' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'training_id' => 1,
                'client_id' => 2,
                'trainer_id' => 1,
                'created_at' => now(),
                'updated_at' => now()
            ]
        ]);
    }
}