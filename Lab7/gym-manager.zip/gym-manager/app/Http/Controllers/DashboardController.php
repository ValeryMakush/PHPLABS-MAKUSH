<?php

namespace App\Http\Controllers;

use App\Models\Client;
use App\Models\Training;
use App\Models\Trainer;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View 
    {
        $stats = [
            'trainings_count' => Training::sum('sessions_count'),
            'clients_count' => Client::count(),
            'trainers_count' => Trainer::count(),
            'today_trainings' => Training::whereDate('training_date', today())->sum('sessions_count')
        ];

        $latest_trainings = Training::with('trainer')
            ->latest()
            ->take(5)
            ->get();

        $active_clients = Client::select('clients.*')
            ->leftJoin('training_client_trainer', 'clients.id', '=', 'training_client_trainer.client_id')
            ->leftJoin('trainings', 'training_client_trainer.training_id', '=', 'trainings.id')
            ->groupBy('clients.id')
            ->select('clients.*', DB::raw('SUM(trainings.sessions_count) as trainings_count'))
            ->having('trainings_count', '>', 0)
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact('stats', 'latest_trainings', 'active_clients'));
    }
}