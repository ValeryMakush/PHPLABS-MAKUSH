@extends('adminlte::page')

@section('title', 'Звіт по тренерам')

@section('content')
<div class="content-header">
    <div class="container-fluid">
        <h1>Звіт по тренерам</h1>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Тренер</th>
                            <th>Тренування</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($trainers as $trainer)
                            <tr>
                                <td>{{ $trainer->name }}</td>
                                <td>
                                    @forelse($trainer->trainings as $training)
                                        <div class="mb-2">
                                            <strong>{{ $training->name }}</strong>
                                            <br>
                                            <small>Дата: {{ $training->training_date?->format('d.m.Y') ?? 'Не вказано' }}</small>
                                            <br>
                                            <small>Клієнти:</small>
                                            <ul class="mb-0">
                                                @foreach($training->clients as $client)
                                                    @if($client->pivot->trainer_id == $trainer->id)
                                                        <li>{{ $client->name }} ({{ $client->pivot->quantity }})</li>
                                                    @endif
                                                @endforeach
                                            </ul>
                                        </div>
                                    @empty
                                        <p>Немає тренувань</p>
                                    @endforelse
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="2" class="text-center">Тренери не знайдені</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection
