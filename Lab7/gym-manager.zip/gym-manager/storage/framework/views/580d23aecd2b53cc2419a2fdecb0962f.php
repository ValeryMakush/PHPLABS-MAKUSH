

<?php $__env->startSection('title', 'Тренери'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Список тренерів</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <a href="<?php echo e(route('trainers.create')); ?>" class="btn btn-success mb-3">Додати тренера</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ім'я</th>
                <th>Email</th>
                <th>Телефон</th>
                <th>Дії</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trainers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trainer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($trainer->name); ?></td>
                    <td><?php echo e($trainer->email); ?></td>
                    <td><?php echo e($trainer->phone); ?></td>
                    <td>
                        <a href="<?php echo e(route('trainers.edit', $trainer)); ?>" class="btn btn-warning btn-sm">Редагувати</a>
                        <form action="<?php echo e(route('trainers.destroy', $trainer)); ?>" method="POST" style="display:inline-block">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Видалити тренера?')">Видалити</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/trainers/index.blade.php ENDPATH**/ ?>