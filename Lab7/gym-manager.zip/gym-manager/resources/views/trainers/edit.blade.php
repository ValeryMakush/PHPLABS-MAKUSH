@extends('adminlte::page')

@section('title', 'Редагування тренера')

@section('content_header')
    <h1>Редагувати тренера</h1>
@stop

@section('content')
    <form action="{{ route('trainers.update', $trainer) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="form-group">
            <label>Ім’я</label>
            <input type="text" name="name" value="{{ $trainer->name }}" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="{{ $trainer->email }}" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" value="{{ $trainer->phone }}" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Зберегти</button>
    </form>
@stop
