<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Training extends Model
{
    protected $fillable = [
        'name',
        'training_type_id',
        'trainer_id',
        'training_date',
        'sessions_count',
        'status',
        'notes'
    ];

    protected $casts = [
        'training_date' => 'datetime'
    ];

    public function trainer(): BelongsTo
    {
        return $this->belongsTo(Trainer::class);
    }

    public function trainingType(): BelongsTo
    {
        return $this->belongsTo(TrainingType::class);
    }

    public function clients(): BelongsToMany
    {
        return $this->belongsToMany(Client::class, 'training_client_trainer')
                    ->withPivot('trainer_id')
                    ->withTimestamps();
    }
}
