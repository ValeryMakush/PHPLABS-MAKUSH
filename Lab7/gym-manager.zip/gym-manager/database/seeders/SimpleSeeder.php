<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Trainer;
use App\Models\Client;
use App\Models\Training;
use App\Models\TrainingType;

class SimpleSeeder extends Seeder
{
    public function run()
    {
        // Створюємо тип тренування (якщо його немає)
        $trainingType = TrainingType::create([
            'name' => 'Yoga',
            'description' => 'Тип тренування - Йога',
        ]);

        // Створюємо тренера
        $trainer = Trainer::create([
            'name' => 'Oleg',
            'email' => 'oleg@example.com',
            'phone' => '1234567890',
        ]);

        // Створюємо тренування з правильним training_type_id
        $training = Training::create([
            'name' => 'Yoga Session',
            'description' => 'Morning yoga',
            'training_type_id' => $trainingType->id,
            'training_date' => now()->addDays(1),
            'trainer_id' => $trainer->id,
        ]);

        // Створюємо клієнтів
        $client1 = Client::create([
            'name' => 'Client One',
            'email' => 'client1@example.com',
        ]);
        $client2 = Client::create([
            'name' => 'Client Two',
            'email' => 'client2@example.com',
        ]);

        // Прив’язуємо клієнтів до тренера з тренуванням
        $trainer->clients()->attach([
            $client1->id => ['training_id' => $training->id],
            $client2->id => ['training_id' => $training->id],
        ]);
    }
}
