@extends('adminlte::page')

@section('title', 'Тренери')

@section('content_header')
    <h1>Список тренерів</h1>
@stop

@section('content')
    <a href="{{ route('trainers.create') }}" class="btn btn-success mb-3">Додати тренера</a>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ім'я</th>
                <th>Email</th>
                <th>Телефон</th>
                <th>Дії</th>
            </tr>
        </thead>
        <tbody>
            @foreach($trainers as $trainer)
                <tr>
                    <td>{{ $trainer->name }}</td>
                    <td>{{ $trainer->email }}</td>
                    <td>{{ $trainer->phone }}</td>
                    <td>
                        <a href="{{ route('trainers.edit', $trainer) }}" class="btn btn-warning btn-sm">Редагувати</a>
                        <form action="{{ route('trainers.destroy', $trainer) }}" method="POST" style="display:inline-block">
                            @csrf
                            @method('DELETE')
                            <button class="btn btn-danger btn-sm" onclick="return confirm('Видалити тренера?')">Видалити</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@stop
