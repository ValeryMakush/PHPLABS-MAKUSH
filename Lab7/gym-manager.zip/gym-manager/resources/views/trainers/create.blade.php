@extends('adminlte::page')

@section('title', 'Додати тренера')

@section('content_header')
    <h1>Додати тренера</h1>
@stop

@section('content')
    @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form action="{{ route('trainers.store') }}" method="POST">
        @csrf

        <div class="form-group">
            <label>Ім’я</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" class="form-control">
        </div>

        <button type="submit" class="btn btn-primary">Зберегти</button>
    </form>
@stop
