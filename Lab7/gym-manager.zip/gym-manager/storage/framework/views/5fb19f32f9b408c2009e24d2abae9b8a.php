

<?php $__env->startSection('title', 'Види тренувань'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="d-flex justify-content-between">
        <h1>Види тренувань</h1>
        <a href="<?php echo e(route('training-types.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Додати вид тренування
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 50px">#</th>
                    <th>Назва</th>
                    <th>Опис</th>
                    <th style="width: 150px">Дії</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($type->name); ?></td>
                        <td><?php echo e($type->description ?? 'Немає опису'); ?></td>
                        <td>
                            <a href="<?php echo e(route('training-types.edit', $type->id)); ?>" class="btn btn-sm btn-warning">
                                <i class="fas fa-edit"></i> Редагувати
                            </a>
                            <form action="<?php echo e(route('training-types.destroy', $type->id)); ?>" method="POST" style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Ви впевнені?')">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="text-center">Немає видів тренувань</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH F:\laragon\www\gym-manager\resources\views/training_types/index.blade.php ENDPATH**/ ?>