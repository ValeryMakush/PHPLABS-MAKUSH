<?php

namespace App\Http\Controllers;

use App\Models\Trainer;

class ReportController extends Controller
{
   public function report()
{
    // Завантажуємо тренерів з клієнтами через проміжну таблицю
    $trainers = Trainer::with(['clients'])->get();

    // Обчислюємо загальну кількість тренувань (сума quantity в проміжній таблиці)
    foreach ($trainers as $trainer) {
        $trainer->quantity = \DB::table('training_client_trainer')
            ->where('trainer_id', $trainer->id)
            ->sum('quantity');
    }

    return view('reports.trainings_by_trainer', compact('trainers'));
}


}
